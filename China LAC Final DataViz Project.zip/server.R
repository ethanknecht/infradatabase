#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {

    output$chinaPlot <- renderPlot({
        
        cd <- ggplot(china_data) +
            geom_bar(aes(x=get(input$xVar), fill=get(input$yVar)), position = "fill")+
            theme(axis.text.x = element_text(angle = 90)) +
            xlab(input$xVar) +
            ylab("Proportion of projects that face resistance") +
            scale_fill_manual(name="Did the project\nface resistance?", 
                              values = c("#00BFC4", "#F8766D"))
        
        if(input$facet == "zip") {cd}
        else {cd + facet_wrap(.~ get(input$facet))}
        
    })

})
