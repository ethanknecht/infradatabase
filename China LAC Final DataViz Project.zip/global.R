library(shiny)
library(tidyverse)
library(readr)

china_data <- read.csv("China_LAC.csv")
china_data <- china_data[c(1:205), ]

## RESISTANCE VARIABLES
## Turning all resistance variables into factors
china_data$E <- as.factor(china_data$E)
china_data <- mutate(china_data, E = fct_recode(E, "Yes" = "1", "No" = "0"))
china_data$L <- as.factor(china_data$L)
china_data <- mutate(china_data, L = fct_recode(L, "Yes" = "1", "No" = "0"))
china_data$L2 <- as.factor(china_data$L2)
china_data <- mutate(china_data, L2 = fct_recode(L2, "Yes" = "1", "No" = "0"))
china_data$I <- as.factor(china_data$I)
china_data <- mutate(china_data, I = fct_recode(I, "Yes" = "1", "No" = "0"))
china_data$C <- as.factor(china_data$C)
china_data <- mutate(china_data, C = fct_recode(C, "Yes" = "1", "No" = "0"))
china_data$B <- as.factor(china_data$B)
china_data <- mutate(china_data, B = fct_recode(B, "Yes" = "1", "No" = "0"))

## Year as a factor
china_data$Year <- as.factor(as.numeric(china_data$Year))

## Adjusting completion as a factor
china_data$Complete <- as.factor(china_data$Complete)
china_data <- mutate(china_data, Complete = fct_recode(Complete, 
                                                       "Incomplete" = "0", 
                                                       "Complete" = "1"))

## Adjusting "none" variable 
china_data <- mutate(china_data, Resistance = None == "0")
china_data$Resistance <- as.factor(china_data$Resistance)
china_data <- mutate(china_data, Resistance = fct_recode(Resistance, 
                                                         "Yes" = "TRUE", 
                                                         "No" = "FALSE"))
china_data <- filter(china_data, !is.na(Resistance))

## FACETING
## Mutating data so that International Invovlement is True/False
china_data <- mutate(china_data, International = Involvement == c(1,2,3))
china_data$International <- as.factor(china_data$International)
china_data <- mutate(china_data, International = fct_recode(International, 
                                                         "Only Chinese" = "TRUE", 
                                                         "Non-Chinese Involvement" = "FALSE"))
china_data <- filter(china_data, !is.na(International))


## Mutating data to create a new variable for four kinds of amount

china_data <- mutate(china_data, Size=ifelse(Amount < 100000000, "Small",
                                                 ifelse(Amount < 500000000, "Medium",
                                                        ifelse(Amount < 1000000000, "Large",
                                                               ifelse(Amount >= 1000000000, "Mega Project", "NA")))))

