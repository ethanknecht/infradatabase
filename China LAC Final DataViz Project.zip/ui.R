#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

    # Application title
    titlePanel("Resistance to Chinese-Backed Infrastructure in Latin America and the Caribbean"),

    # Sidebar with a slider input for number of bins
    sidebarLayout(
        sidebarPanel(
            selectInput("yVar", label = h3("Filter Resistance by Issue"), 
                               choices = list("All Resistance" = "Resistance",
                                              "Environment" = "E", 
                                              "Labor Rights" = "L", 
                                              "Imported Labor" = "L2",
                                              "Indigenous/Land Rights" = "I",
                                              "Corruption" = "C",
                                              "Contract Issue" = "B"),
                               selected = "Resistance"),
            selectInput("xVar", label = h3("Choose a Project Attribute"), 
                        choices = list("Host Country" = "Country", 
                                       "Project Start Year" = "Year", 
                                       "Type of Project" = "Type",
                                       "Project Sector" = "Sector",
                                       "Completion" = "Complete",
                                       "International Involvement" = "International"), 
                        selected = "Country"),
            radioButtons("facet", label = h3("Facet Data by ___?"),
                         choices = list("None" = "zip", 
                                        "International Involvement" = "International",
                                        "Size of Project" = "Size",
                                        "Project Sector" = "Sector",
                                        "Completion" = "Complete"), 
                         selected = "zip"),
        ),

        # Show a plot of the generated distribution
        mainPanel(
            plotOutput("chinaPlot"),
            h1("Notes"),
            p("This tool shows the rates of resistance that Chinese-backed infrastructure projects face in Latin American and Caribbean (LAC) countries. 
              The database was created as part of an undergraduate thesis with the Georgetown Center for Latin American Studies. Chinese-backed projects include
              all infrastructure projects that were built in the region with financing, investment, or construction assistance from at least one Chinese
              entity. Other non-Chinese entities, including financiers like the IDB and World Bank, domestic Latin American construction firms like Odebrecht,
              and international construction firms like DP World were also involved in these projects, although their participation is not separated here."),
            p("The database currently encompasses (as of May 2020) projects in the LAC from between 2008 and 2020 worth at least $10 million dollars."),
            h2("Definitions of Key Terms"),
            p(strong("Resistance"), "is either a protest or a government action against a project. This could include a demonstration, a strike, a government investigation, a contract cancellation by the government, or 
            a fine levied by the government for violating local or national laws. Types of resistance, like environment, labor rights, corruption, indigneous and land rights, are self explanatory.
              Labor importation refers to dissent over whether the Chinese were importing Chinese workers to construct a project. Contractual issues refers to whether a company on that project had faced resistance 
              over not following the contract (such as not completing the project on time)."),
            p(strong("Host Country"), "is the LAC country a project is hosted in. Note that there were two projects that spanned more than one country (the Colombian-Venzuelan pipeline and the 
              bi-oceanic railroad that would cross Brazil, Paraguay, and Peru). In these cases, the project was attributed to the country that was either leading the project development (Colombia
              in the Colombian-Venezuelan Pipeline) or would host the largest span of the project (Brazil in the bi-oceanic railway)."),
            p(strong("Project Start Year"), "is the first year recorded in international media for a project."),
            p(strong("Type and Sector"), "are the different categories a project was separated into, as reported by the media. Sector is broader, and is composed of many different types (e.g. energy
              is a sector, while hydroelectric dam, solar park, and power plant are types of projects within that sector)."),
            p(strong("Completion"), "is whether or not a project has been announced as completed."),
            p(strong("International Involvement"), "is the involvement by some actor other than just the Chinese. Chinese-only projects may have been paid for or designed
              by the customer (usually the host government), but no non-Chinese actor was involved in providing additional financing or construction support."),
            p(strong("Size of Project"), "is defined by the largest (accurately reported) value of a project in the media. Small projects are worth less than $100 million,
              medium projects are valued between $100 million and $500 million, large projects are valued between $500 million and $1 billion, and mega-projects are valued over
              $1 billion."),
            p(""),
            h2("Download the data at:"),
            p(" ",a("China LAC Database",href="https://github.com/ethanknecht/chinaLAC20.git")),
            p(strong("Last Updated May 7, 2020 by Ethan Knecht"))
        )
    )
))
